This dataset provides landuses from 1988 to 2015 in Shenzhen which has be used in the article 'Dynamic monitoring of land use land cover change and urban expansion in Shenzhen using Landsat imagery from 1988 to 2015'. If you want to make use of this dataset, please cite our following paper.

Peng Dou & Yangbo Chen (2017) Dynamic monitoring of land-use/land-cover change and urban expansion in Shenzhen using Landsat imagery from 1988 to 2015, International Journal of Remote Sensing, 38:19, 5388-5407, DOI: 10.1080/01431161.2017.1339926
Peng Dou & Yangbo Chen (2017) Remote sensing imagery classification using AdaBoost with a weight vector (WV AdaBoost), Remote Sensing Letters, 8:8, 733-742, DOI: 10.1080/2150704X.2017.1319987
Peng Dou, Yangbo Chen & Haiyun Yue (2018) Remote-sensing imagery classification using multiple classification algorithm-based AdaBoost, International Journal of
Remote Sensing, 39:3, 619-639



value	category
1	 forest
2	 grassland
3	 cultivated land
4	 built-up area
5	 bear land
6	 waterbody